import { Suspense } from 'react'
import { SalesOverview } from '@/components/sales-overview'
import { SalesTrends } from '@/components/sales-trends'
import { TopSellingItems } from '@/components/top-selling-items'
import { StockAlerts } from '@/components/stock-alerts'
import { MenuRecommendations } from '@/components/menu-recommendations'
import { InventoryManagement } from '@/components/inventory-management'
import { ReportGenerator } from '@/components/report-generator'
import { Settings } from '@/components/settings'
import { NewMenu } from '@/components/new-menu'
import { SalesPrediction } from '@/components/sales-prediction'

export default function Dashboard() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Dashboard Sinergy Queens</h1>
      
      <div className="mb-8">
        <NewMenu />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Suspense fallback={<div>Loading sales overview...</div>}>
          <SalesOverview />
        </Suspense>
        
        <Suspense fallback={<div>Loading sales trends...</div>}>
          <SalesTrends />
        </Suspense>
        
        <Suspense fallback={<div>Loading sales prediction...</div>}>
          <SalesPrediction />
        </Suspense>
        
        <Suspense fallback={<div>Loading top selling items...</div>}>
          <TopSellingItems />
        </Suspense>
        
        <Suspense fallback={<div>Loading stock alerts...</div>}>
          <StockAlerts />
        </Suspense>
        
        <Suspense fallback={<div>Loading menu recommendations...</div>}>
          <MenuRecommendations />
        </Suspense>
      </div>
      
      <div className="mt-8">
        <Suspense fallback={<div>Loading inventory management...</div>}>
          <InventoryManagement />
        </Suspense>
      </div>
      
      <div className="mt-8">
        <Suspense fallback={<div>Loading report generator...</div>}>
          <ReportGenerator />
        </Suspense>
      </div>
      
      <div className="mt-8">
        <Suspense fallback={<div>Loading settings...</div>}>
          <Settings />
        </Suspense>
      </div>
    </div>
  )
}

