'use client'

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

// Ini adalah data contoh. Dalam implementasi nyata, data ini akan berasal dari backend
const predictionData = [
  { date: "1 Sep", actual: 250000, predicted: 260000 },
  { date: "2 Sep", actual: 280000, predicted: 275000 },
  { date: "3 Sep", actual: 270000, predicted: 290000 },
  { date: "4 Sep", actual: 290000, predicted: 300000 },
  { date: "5 Sep", actual: 310000, predicted: 305000 },
  { date: "6 Sep", predicted: 320000 },
  { date: "7 Sep", predicted: 330000 },
]

export function SalesPrediction() {
  const lastActualDate = predictionData.filter(d => d.actual).pop()?.date
  const totalActual = predictionData.reduce((sum, d) => sum + (d.actual || 0), 0)
  const totalPredicted = predictionData.reduce((sum, d) => sum + d.predicted, 0)
  const growthRate = ((totalPredicted - totalActual) / totalActual * 100).toFixed(2)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Prediksi Penjualan</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={predictionData}>
              <XAxis 
                dataKey="date" 
                stroke="#888888" 
                fontSize={12} 
                tickLine={false} 
                axisLine={false}
              />
              <YAxis
                stroke="#888888"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `Rp${(value/1000).toFixed(0)}k`}
              />
              <Tooltip 
                formatter={(value: number) => [`Rp${value.toLocaleString('id-ID')}`, "Penjualan"]}
                labelFormatter={(label) => `Tanggal: ${label}`}
              />
              <Line type="monotone" dataKey="actual" stroke="#8884d8" strokeWidth={2} name="Aktual" />
              <Line type="monotone" dataKey="predicted" stroke="#82ca9d" strokeWidth={2} strokeDasharray="5 5" name="Prediksi" />
            </LineChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-sm text-muted-foreground">Total Aktual (sampai {lastActualDate})</p>
              <p className="text-2xl font-bold">Rp{totalActual.toLocaleString('id-ID')}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Prediksi (7 hari)</p>
              <p className="text-2xl font-bold">Rp{totalPredicted.toLocaleString('id-ID')}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Prediksi Pertumbuhan</p>
              <p className={`text-2xl font-bold ${Number(growthRate) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {growthRate}%
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

